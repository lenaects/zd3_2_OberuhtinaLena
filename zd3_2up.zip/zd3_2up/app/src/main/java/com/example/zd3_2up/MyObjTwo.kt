package com.example.zd3_2up

class MyObjTwo(private val answer: List<Movie>){ val list = arrayListOf(
    Movie(answer[0].name, answer[0].img, answer[0].info),
    Movie(answer[1].name, answer[1].img, answer[1].info),
    Movie(answer[2].name, answer[2].img, answer[2].info),
    Movie(answer[3].name, answer[3].img, answer[3].info),
    Movie(answer[4].name, answer[4].img, answer[4].info),
    Movie(answer[5].name, answer[5].img, answer[5].info),

    )}