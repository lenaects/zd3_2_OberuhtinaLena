package com.example.zd3_2up

import android.app.Activity
import android.os.Bundle

class RecycleItem : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recycle_item)
    }
}