package com.example.zd3_2up

data class Movie(
    val name: String,
    val img: String,
    val info: String
)