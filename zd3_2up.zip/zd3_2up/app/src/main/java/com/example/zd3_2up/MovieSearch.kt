package com.example.zd3_2up

data class MovieSearch (
    val Title: String,
    val Poster: String,
    val Released: String,
    val Year: String,
    val Writer: String,
    val Actors: String

)